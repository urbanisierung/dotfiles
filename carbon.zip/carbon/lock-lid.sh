#!/bin/sh
xss-lock -- ~/scripts/lock.sh &

